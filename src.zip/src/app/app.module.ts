import { NgModule, ErrorHandler } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { IonicApp, IonicModule, IonicErrorHandler } from 'ionic-angular';
import { MyApp } from './app.component';
import { ListarMoveisPage } from '../pages/listar-moveis/listar-moveis';
import { ListarInquilinoPage } from '../pages/listar-inquilino/listar-inquilino';
import { ListarLeituraPage } from '../pages/listar-leitura/listar-leitura';
import { AvisosPage } from '../pages/avisos/avisos';
import { TabsControllerPage } from '../pages/tabs-controller/tabs-controller';
import { LoginPage } from '../pages/login/login';
import { InscreverSePage } from '../pages/inscrever-se/inscrever-se';
import { InquilinoPage } from '../pages/inquilino/inquilino';
import { ImovelPage } from '../pages/imovel/imovel';
import { RegistroDaLeituraPage } from '../pages/registro-da-leitura/registro-da-leitura';


import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';

@NgModule({
  declarations: [
    MyApp,
    ListarMoveisPage,
    ListarInquilinoPage,
    ListarLeituraPage,
    AvisosPage,
    TabsControllerPage,
    LoginPage,
    InscreverSePage,
    InquilinoPage,
    ImovelPage,
    RegistroDaLeituraPage
  ],
  imports: [
    BrowserModule,
    IonicModule.forRoot(MyApp)
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    ListarMoveisPage,
    ListarInquilinoPage,
    ListarLeituraPage,
    AvisosPage,
    TabsControllerPage,
    LoginPage,
    InscreverSePage,
    InquilinoPage,
    MovelPage,
    RegistroDaLeituraPage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    {provide: ErrorHandler, useClass: IonicErrorHandler}
  ]
})
export class AppModule {}