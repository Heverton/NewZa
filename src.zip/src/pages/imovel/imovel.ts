import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-imovel',
  templateUrl: 'imovel.html'
})
export class ImovelPage {

  constructor(public navCtrl: NavController) {
  }
  
}
