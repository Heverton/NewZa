import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-registro-da-leitura',
  templateUrl: 'registro-da-leitura.html'
})
export class RegistroDaLeituraPage {

  constructor(public navCtrl: NavController) {
  }
  
}
