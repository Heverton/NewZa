import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-avisos',
  templateUrl: 'avisos.html'
})
export class AvisosPage {

  constructor(public navCtrl: NavController) {
  }
  
}
