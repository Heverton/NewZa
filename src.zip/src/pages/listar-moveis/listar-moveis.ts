import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { MovelPage } from '../movel/movel';

@Component({
  selector: 'page-listar-moveis',
  templateUrl: 'listar-moveis.html'
})
export class ListarMoveisPage {

  constructor(public navCtrl: NavController) {
  }
  goToMovel(params){
    if (!params) params = {};
    this.navCtrl.push(MovelPage);
  }
}
