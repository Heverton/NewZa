import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { RegistroDaLeituraPage } from '../registro-da-leitura/registro-da-leitura';

@Component({
  selector: 'page-listar-leitura',
  templateUrl: 'listar-leitura.html'
})
export class ListarLeituraPage {

  constructor(public navCtrl: NavController) {
  }
  goToRegistroDaLeitura(params){
    if (!params) params = {};
    this.navCtrl.push(RegistroDaLeituraPage);
  }
}
