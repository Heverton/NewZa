import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { AvisosPage } from '../avisos/avisos';
import { AvisosPage } from '../avisos/avisos';
import { ListarMoveisPage } from '../listar-moveis/listar-moveis';
import { ListarInquilinoPage } from '../listar-inquilino/listar-inquilino';
import { ListarLeituraPage } from '../listar-leitura/listar-leitura';

@Component({
  selector: 'page-tabs-controller',
  templateUrl: 'tabs-controller.html'
})
export class TabsControllerPage {

  tab1Root: any = AvisosPage;
  tab2Root: any = ListarMoveisPage;
  tab3Root: any = ListarInquilinoPage;
  tab4Root: any = ListarLeituraPage;
  constructor(public navCtrl: NavController) {
  }
  goToAvisos(params){
    if (!params) params = {};
    this.navCtrl.push(AvisosPage);
  }
}
