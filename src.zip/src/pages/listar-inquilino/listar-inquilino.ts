import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { InquilinoPage } from '../inquilino/inquilino';

@Component({
  selector: 'page-listar-inquilino',
  templateUrl: 'listar-inquilino.html'
})
export class ListarInquilinoPage {

  constructor(public navCtrl: NavController) {
  }
  goToInquilino(params){
    if (!params) params = {};
    this.navCtrl.push(InquilinoPage);
  }
}
