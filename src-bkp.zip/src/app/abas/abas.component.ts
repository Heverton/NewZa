import { Component } from '@angular/core';
import { NavController } from '@ionic/angular';
import { AvisosPage } from '../pages/avisos/avisos';
import { ListarMoveisPage } from '../pages/listar-moveis/listar-moveis';
import { ListarInquilinoPage } from '../pages/listar-inquilino/listar-inquilino';
import { ListarLeituraPage } from '../pages/listar-leitura/listar-leitura';

@Component({
  selector: 'app-abas',
  templateUrl: 'tabs-controller.html'
})
export class AbasComponent {

  tab1Root: any = AvisosPage;
  tab2Root: any = ListarMoveisPage;
  tab3Root: any = ListarInquilinoPage;
  tab4Root: any = ListarLeituraPage;

  constructor(public navCtrl: NavController) {
  }

  goToAvisos(params: any){
    // if (!params) params = {};
    // this.navCtrl.push(AvisosPage);
  }
}
