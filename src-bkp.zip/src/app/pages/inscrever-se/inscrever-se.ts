import { Component } from '@angular/core';
import { NavController } from '@ionic/angular';

@Component({
  selector: 'page-inscrever-se',
  templateUrl: 'inscrever-se.html'
})
export class InscreverSePage {

  constructor() {
  }

}
