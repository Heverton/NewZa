import { Component } from '@angular/core';
import { NavController } from '@ionic/angular';

@Component({
  selector: 'page-inquilino',
  templateUrl: 'inquilino.html'
})
export class InquilinoPage {

  constructor(public navCtrl: NavController) {
  }
  
}
