import { Component } from '@angular/core';
import { NavController } from '@ionic/angular';

@Component({
  selector: 'page-listar-moveis',
  templateUrl: 'listar-moveis.html'
})
export class ListarMoveisPage {

  constructor(public navCtrl: NavController) {
  
  }

  goToMovel(params){
    // if (!params) params = {};
    // this.navCtrl.push(ImovelPage);
  }
}
