import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouteReuseStrategy } from '@angular/router';
import { IonicModule, IonicRouteStrategy } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ListarMoveisPage } from './pages/listar-moveis/listar-moveis';
import { ListarInquilinoPage } from './pages/listar-inquilino/listar-inquilino';
import { ListarLeituraPage } from './pages/listar-leitura/listar-leitura';
import { AvisosPage } from './pages/avisos/avisos';
import { LoginPage } from './pages/login/login';
import { InscreverSePage } from './pages/inscrever-se/inscrever-se';
import { InquilinoPage } from './pages/inquilino/inquilino';
import { ImovelPage } from './pages/imovel/imovel';
import { RegistroDaLeituraPage } from './pages/registro-da-leitura/registro-da-leitura';
import { TabsControllerPage } from './pages/tabs-controller/tabs-controller';

@NgModule({
  declarations: [
    AppComponent,
    TabsControllerPage,
    ListarMoveisPage,
    ListarInquilinoPage,
    ListarLeituraPage,
    AvisosPage,
    LoginPage,
    InscreverSePage,
    InquilinoPage,
    ImovelPage,
    RegistroDaLeituraPage],
  entryComponents: [],
  imports: [
    BrowserModule,
    IonicModule.forRoot(),
    AppRoutingModule],
  providers: [
    StatusBar,
    SplashScreen,
    { provide: RouteReuseStrategy, useClass: IonicRouteStrategy }
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}
